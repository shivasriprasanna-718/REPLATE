/* ============================================================
   REPLATE — routes/recipients.js
   NGO / shelter / daycare registration.
   ============================================================ */

const express = require("express");
const { readDB, writeDB, nextId } = require("../utils/db");

const router = express.Router();

router.get("/", (req, res) => {
  const db = readDB();
  res.json(db.recipients);
});

router.post("/", (req, res) => {
  const db = readDB();
  const { orgName, orgType, contactPerson, phone, address, capacity, preferredType, timings } = req.body;

  if (!orgName || !orgType || !contactPerson || !phone || !address) {
    return res.status(400).json({ message: "Missing required fields." });
  }

  const recipient = {
    id: nextId("r", db.recipients),
    orgName,
    orgType,
    contactPerson,
    phone,
    address,
    capacity: Number(capacity) || 0,
    preferredType: preferredType || "Any",
    timings: timings || "",
    createdAt: new Date().toISOString(),
  };

  db.recipients.push(recipient);
  writeDB(db);
  res.status(201).json(recipient);
});

module.exports = router;
