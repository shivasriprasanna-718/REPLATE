/* ============================================================
   REPLATE — routes/volunteers.js
   Volunteer registration and the Kindness Points leaderboard.
   ============================================================ */

const express = require("express");
const { readDB, writeDB, nextId } = require("../utils/db");

const router = express.Router();

// POST /api/volunteers — register a new volunteer
router.post("/", (req, res) => {
  const db = readDB();
  const { name, phone, area } = req.body;

  if (!name || !phone) {
    return res.status(400).json({ message: "Missing required fields." });
  }

  const volunteer = {
    id: nextId("v", db.volunteers),
    name,
    phone,
    area: area || "",
    points: 0,
    createdAt: new Date().toISOString(),
  };

  db.volunteers.push(volunteer);
  writeDB(db);
  res.status(201).json(volunteer);
});

// GET /api/leaderboard — donors (by donation points) + volunteers, combined and ranked
router.get("/leaderboard", (req, res) => {
  const db = readDB();

  const donorPoints = {};
  db.donations.forEach((d) => {
    donorPoints[d.source] = (donorPoints[d.source] || 0) + d.points;
  });

  const donorEntries = Object.entries(donorPoints).map(([name, points]) => ({ name, points }));
  const volunteerEntries = db.volunteers.map((v) => ({ name: v.name, points: v.points }));

  const combined = [...donorEntries, ...volunteerEntries].sort((a, b) => b.points - a.points);
  res.json(combined);
});

module.exports = router;
