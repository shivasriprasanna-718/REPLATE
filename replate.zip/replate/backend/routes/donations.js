/* ============================================================
   REPLATE — routes/donations.js
   Everything about a donor's "pickup request": creating one,
   listing them for the volunteer dashboard, and updating status
   as a volunteer collects and delivers the food.
   ============================================================ */

const express = require("express");
const { readDB, writeDB, nextId } = require("../utils/db");

const router = express.Router();

// GET /api/donations — list all pickups (newest first)
router.get("/", (req, res) => {
  const db = readDB();
  const sorted = [...db.donations].sort(
    (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
  );
  res.json(sorted);
});

// POST /api/donations — donor requests a pickup
router.post("/", (req, res) => {
  const db = readDB();
  const { source, contact, foodType, quantity, address, pickupTime, expiry, notes, photoCount } = req.body;

  if (!source || !contact || !foodType || !quantity || !address) {
    return res.status(400).json({ message: "Missing required fields." });
  }

  const donation = {
    id: nextId("d", db.donations),
    source,
    contact,
    foodType,
    quantity,
    address,
    pickupTime: pickupTime || null,
    expiry: expiry || null,
    notes: notes || "",
    photoCount: Number(photoCount) || 0,
    status: "pending",
    verified: false,
    points: 20, // base Kindness Points for donating
    createdAt: new Date().toISOString(),
  };

  db.donations.push(donation);
  writeDB(db);
  res.status(201).json(donation);
});

// PATCH /api/donations/:id/status — volunteer marks completed / delivered
router.patch("/:id/status", (req, res) => {
  const db = readDB();
  const { status } = req.body;
  const allowed = ["pending", "completed", "delivered"];

  if (!allowed.includes(status)) {
    return res.status(400).json({ message: `Status must be one of: ${allowed.join(", ")}` });
  }

  const donation = db.donations.find((d) => d.id === req.params.id);
  if (!donation) return res.status(404).json({ message: "Donation not found." });

  donation.status = status;
  if (status === "completed") donation.verified = true; // simple hygiene-check stand-in
  writeDB(db);
  res.json(donation);
});

module.exports = router;
