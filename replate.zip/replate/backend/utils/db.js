/* ============================================================
   REPLATE — utils/db.js
   Our "database" is just a JSON file on disk (data/db.json).
   That's enough for a student project / demo: no server setup,
   easy to inspect, and easy to explain in a presentation.
   ============================================================ */

const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "..", "data", "db.json");

function readDB() {
  const raw = fs.readFileSync(DB_PATH, "utf-8");
  return JSON.parse(raw);
}

function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function nextId(prefix, list) {
  return `${prefix}${list.length + 1}-${Date.now().toString(36)}`;
}

module.exports = { readDB, writeDB, nextId };
